  function navFunction() {
    var targets = document.getElementsByClassName("mobnav");
    for(var i=0; i < targets.length;i++){
      targets[i].classList.toggle("show");
    }
  }
  
(function() {
var cx = '013516846811604855281:nj5laplixaa'; // Insert your own Custom Search engine ID here
var gcse = document.createElement('script'); gcse.type = 'text/javascript'; gcse.async = true;
gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(gcse, s);
})()